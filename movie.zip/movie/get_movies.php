<?php
require_once 'config.php';

// Get search and page parameters
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 12;
$offset = ($page - 1) * $records_per_page;

// Build the SQL query based on search
$where_clause = '';
$params = [];
$param_types = '';

if (!empty($search)) {
    $where_clause = "WHERE title LIKE ?";
    $params[] = "%$search%";
    $param_types = 's';
}

// Get total records for pagination
$total_pages_sql = "SELECT COUNT(*) FROM movies " . $where_clause;
if (!empty($params)) {
    $stmt = $conn->prepare($total_pages_sql);
    $stmt->bind_param($param_types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $total_rows = $result->fetch_array()[0];
    $stmt->close();
} else {
    $result = $conn->query($total_pages_sql);
    $total_rows = $result->fetch_array()[0];
}

$total_pages = ceil($total_rows / $records_per_page);

// Get movies with pagination and search
$sql = "SELECT m.*, u.name as added_by_name 
        FROM movies m
        LEFT JOIN users u ON m.added_by = u.id " .
        $where_clause . 
        " ORDER BY m.created_at DESC LIMIT ?, ?";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $params[] = $offset;
    $params[] = $records_per_page;
    $param_types .= 'ii';
    $stmt->bind_param($param_types, ...$params);
} else {
    $stmt->bind_param('ii', $offset, $records_per_page);
}

$stmt->execute();
$movies = $stmt->get_result();

// Start building HTML for movies grid
ob_start();

if ($movies->num_rows > 0):
    while($movie = $movies->fetch_assoc()): ?>
        <div class="col">
            <div class="card h-100 shadow movie-card">
                <img src="<?php echo htmlspecialchars($movie['poster_url'] ?: 'https://via.placeholder.com/300x450?text=No+Poster'); ?>" 
                     class="card-img-top movie-poster" 
                     alt="<?php echo htmlspecialchars($movie['title']); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($movie['title']); ?></h5>
                    <p class="card-text text-muted small">
                        Added by: <?php echo htmlspecialchars($movie['added_by_name'] ?: 'Unknown'); ?>
                    </p>
                    <p class="card-text">
                        <?php 
                        $desc = $movie['description'];
                        echo htmlspecialchars(strlen($desc) > 100 ? substr($desc, 0, 100) . '...' : $desc); 
                        ?>
                    </p>
                </div>
                <div class="card-footer bg-transparent border-top-0">
                    <a href="<?php echo htmlspecialchars($movie['watch_link']); ?>" 
                       class="btn btn-primary w-100" 
                       target="_blank">
                        <i class="bi bi-play-circle"></i> Watch Now
                    </a>
                </div>
            </div>
        </div>
    <?php endwhile;
else: ?>
    <div class="col-12 text-center">
        <div class="alert alert-info">
            <?php if (!empty($search)): ?>
                No movies found matching "<?php echo htmlspecialchars($search); ?>".
            <?php else: ?>
                No movies available yet.
            <?php endif; ?>
        </div>
    </div>
<?php endif;

$movies_html = ob_get_clean();

// Build pagination HTML
ob_start();

if ($total_pages > 1): ?>
    <nav aria-label="Movie pagination" class="mt-4">
        <ul class="pagination justify-content-center">
            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                <a class="page-link" href="javascript:void(0)" data-page="<?php echo $page-1; ?>">Previous</a>
            </li>
            <?php for($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                    <a class="page-link" href="javascript:void(0)" data-page="<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                <a class="page-link" href="javascript:void(0)" data-page="<?php echo $page+1; ?>">Next</a>
            </li>
        </ul>
    </nav>
<?php endif;

$pagination_html = ob_get_clean();

// Return JSON response
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'html' => $movies_html,
    'pagination' => $pagination_html
]);

$stmt->close();
$conn->close();
?> 