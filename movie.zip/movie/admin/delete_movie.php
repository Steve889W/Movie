<?php
require_once '../config.php';

// Start session if not already started
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['flash_message'] = [
        'type' => 'warning',
        'message' => 'You do not have permission to delete movies.'
    ];
    header("Location: ../login.php");
    exit();
}

// Process delete operation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $id = sanitizeInput($_POST['id']);
    
    // Delete the movie
    $sql = "DELETE FROM movies WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'message' => 'Movie deleted successfully!'
            ];
        } else {
            $_SESSION['flash_message'] = [
                'type' => 'danger',
                'message' => 'Error deleting movie.'
            ];
        }
        $stmt->close();
    }
    
    header("Location: index.php");
    exit();
} else {
    // If not POST request, redirect to index
    header("Location: index.php");
    exit();
}
?>
