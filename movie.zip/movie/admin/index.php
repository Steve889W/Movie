<?php
// admin/index.php - Admin dashboard
require_once '../config.php';

// Check if user is logged in and is admin
requireAdmin();

// Get all movies with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 10;
$offset = ($page - 1) * $records_per_page;

$total_pages_sql = "SELECT COUNT(*) FROM movies";
$result = $conn->query($total_pages_sql);
$total_rows = $result->fetch_array()[0];
$total_pages = ceil($total_rows / $records_per_page);

$sql = "SELECT m.*, u.name as added_by_name FROM movies m
        LEFT JOIN users u ON m.added_by = u.id
        ORDER BY m.created_at DESC LIMIT $offset, $records_per_page";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - MovieLinks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main {
            flex: 1 0 auto;
        }
        footer {
            flex-shrink: 0;
        }
        .movie-poster {
            width: 50px;
            height: 75px;
            object-fit: cover;
        }
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        .action-buttons .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        @media (max-width: 768px) {
            .table td, .table th {
                white-space: normal;
            }
            .description-cell {
                max-width: 150px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .action-buttons .btn {
                padding: 0.2rem 0.4rem;
                font-size: 0.8rem;
            }
            .btn-group {
                display: flex;
                gap: 2px;
            }
        }
        @media (max-width: 576px) {
            .container {
                padding-left: 10px;
                padding-right: 10px;
            }
            .description-cell {
                max-width: 100px;
            }
            .movie-poster {
                width: 40px;
                height: 60px;
            }
            .pagination {
                flex-wrap: wrap;
                justify-content: center;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="bi bi-film"></i> BihariBabu
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="bi bi-house"></i> View Site
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">
                            <i class="bi bi-speedometer2"></i> Admin Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <span class="nav-link text-light">
                            <i class="bi bi-person"></i> <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?>
                        </span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-shrink-0">
        <div class="container my-4">
            <!-- Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4">
                <h2 class="mb-3 mb-md-0"><i class="bi bi-film"></i> Movie Management</h2>
                <a href="add_movie.php" class="btn btn-success">
                    <i class="bi bi-plus-circle"></i> Add New Movie
                </a>
            </div>

            <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['flash_message']['type']; ?> alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['flash_message']['message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['flash_message']); ?>
            <?php endif; ?>

            <!-- Movies Table -->
            <div class="card shadow">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Poster</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Added By</th>
                                    <th>Date Added</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result->num_rows > 0): ?>
                                    <?php while ($movie = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo htmlspecialchars($movie['poster_url'] ?: 'https://via.placeholder.com/50x75?text=No+Poster'); ?>" 
                                                     alt="<?php echo htmlspecialchars($movie['title']); ?>"
                                                     class="movie-poster rounded"
                                                     loading="lazy">
                                            </td>
                                            <td><?php echo htmlspecialchars($movie['title']); ?></td>
                                            <td class="description-cell">
                                                <?php 
                                                $desc = $movie['description'];
                                                echo htmlspecialchars(strlen($desc) > 100 ? substr($desc, 0, 100) . '...' : $desc); 
                                                ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($movie['added_by_name'] ?: 'Unknown'); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($movie['created_at'])); ?></td>
                                            <td class="action-buttons">
                                                <div class="btn-group">
                                                    <a href="<?php echo htmlspecialchars($movie['watch_link']); ?>" 
                                                       class="btn btn-sm btn-primary" 
                                                       target="_blank" 
                                                       title="Watch Movie">
                                                        <i class="bi bi-play-circle"></i>
                                                    </a>
                                                    <a href="edit_movie.php?id=<?php echo $movie['id']; ?>" 
                                                       class="btn btn-sm btn-warning" 
                                                       title="Edit Movie">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <button type="button" 
                                                            class="btn btn-sm btn-danger" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#deleteModal<?php echo $movie['id']; ?>"
                                                            title="Delete Movie">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </div>

                                                <!-- Delete Confirmation Modal -->
                                                <div class="modal fade" id="deleteModal<?php echo $movie['id']; ?>" tabindex="-1">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Confirm Delete</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure you want to delete "<?php echo htmlspecialchars($movie['title']); ?>"?
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                                <form action="delete_movie.php" method="POST" class="d-inline">
                                                                    <input type="hidden" name="id" value="<?php echo $movie['id']; ?>">
                                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4">
                                            <div class="alert alert-info mb-0">
                                                No movies available yet. <a href="add_movie.php" class="alert-link">Add your first movie</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Movie pagination" class="mt-3 mb-3">
                            <ul class="pagination justify-content-center flex-wrap gap-1">
                                <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page-1; ?>">Previous</a>
                                </li>
                                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page+1; ?>">Next</a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer mt-auto py-3 bg-dark text-white">
        <div class="container">
            <div class="row gy-2 text-center text-md-start">
                <div class="col-md-6">
                    <h5 class="mb-1"><i class="bi bi-film"></i> BihariBabu Admin</h5>
                    <p class="mb-0">Manage your movie collection efficiently.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0">&copy; <?php echo date("Y"); ?> BihariBabu. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>