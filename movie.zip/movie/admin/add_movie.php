<?php
require_once '../config.php';
// Note: config.php already handles session_start()

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['flash_message'] = [
        'type' => 'warning',
        'message' => 'You do not have permission to add movies.'
    ];
    header("Location: ../login.php");
    exit();
}

// Define variables and initialize with empty values
$title = $description = $poster_url = $watch_link = "";
$title_err = $watch_link_err = "";
$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $title = sanitizeInput($_POST["title"] ?? "");
    $description = sanitizeInput($_POST["description"] ?? "");
    $poster_url = sanitizeInput($_POST["poster_url"] ?? "");
    $watch_link = sanitizeInput($_POST["watch_link"] ?? "");

    // Validate required fields
    if (empty($title)) {
        $title_err = "Please enter a title.";
    }
    if (empty($watch_link)) {
        $watch_link_err = "Please enter a watch link.";
    }
    
    // If no errors, insert into database
    if (empty($title_err) && empty($watch_link_err)) {
        $sql = "INSERT INTO movies (title, description, poster_url, watch_link, added_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
        if ($stmt = $conn->prepare($sql)) {
            $added_by = $_SESSION['user_id']; // Use logged in user's ID
            $stmt->bind_param("ssssi", $title, $description, $poster_url, $watch_link, $added_by);
            
            if ($stmt->execute()) {
                setFlashMessage('success', 'Movie added successfully!');
                header("Location: index.php");
                exit();
            } else {
                $success_message = "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Movie - MovieLinks Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .preview-image {
            max-width: 200px;
            max-height: 300px;
            display: none;
            margin-top: 10px;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Add New Movie</h4>
                        <a href="index.php" class="btn btn-outline-light">Back</a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($success_message)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo $success_message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <?php displayFlashMessage(); ?>

                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" id="addMovieForm">
                            <div class="mb-3">
                                <label for="title" class="form-label">Movie Title</label>
                                <input type="text" name="title" id="title" 
                                       class="form-control <?php echo (!empty($title_err)) ? 'is-invalid' : ''; ?>" 
                                       value="<?php echo htmlspecialchars($title); ?>" 
                                       required>
                                <div class="invalid-feedback"><?php echo $title_err; ?></div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea name="description" id="description" class="form-control" 
                                          rows="4"><?php echo htmlspecialchars($description); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="poster_url" class="form-label">Poster URL</label>
                                <input type="url" name="poster_url" id="poster_url" 
                                       class="form-control" 
                                       value="<?php echo htmlspecialchars($poster_url); ?>" 
                                       placeholder="https://example.com/image.jpg">
                                <img id="posterPreview" src="" alt="Poster Preview" class="preview-image">
                            </div>
                            
                            <div class="mb-3">
                                <label for="watch_link" class="form-label">Watch Link</label>
                                <input type="url" name="watch_link" id="watch_link" 
                                       class="form-control <?php echo (!empty($watch_link_err)) ? 'is-invalid' : ''; ?>" 
                                       value="<?php echo htmlspecialchars($watch_link); ?>" 
                                       required>
                                <div class="invalid-feedback"><?php echo $watch_link_err; ?></div>
                            </div>
                            
                            <div class="text-end">
                                <button type="submit" class="btn btn-success">Add Movie</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Preview poster image
        document.getElementById('poster_url').addEventListener('input', function() {
            const preview = document.getElementById('posterPreview');
            const url = this.value;
            
            if (url) {
                preview.src = url;
                preview.style.display = 'block';
                preview.onerror = function() {
                    preview.style.display = 'none';
                };
            } else {
                preview.style.display = 'none';
            }
        });
    </script>
</body>
</html>

