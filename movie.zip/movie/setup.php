<?php
// Include database configuration
require_once 'config.php';

// Create database if it doesn't exist
$create_db = "CREATE DATABASE IF NOT EXISTS " . DB_NAME;
$conn_root = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD);
if ($conn_root->query($create_db) === TRUE) {
    echo "Database created successfully or already exists<br>";
} else {
    echo "Error creating database: " . $conn_root->error . "<br>";
}
$conn_root->close();

// Create users table
$create_table = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($create_table) === TRUE) {
    echo "Users table created successfully or already exists<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

// Check if admin user exists
$check_admin = "SELECT id FROM users WHERE email = 'admin@example.com'";
$result = $conn->query($check_admin);

if ($result->num_rows == 0) {
    // Create admin user if it doesn't exist
    $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
    $create_admin = "INSERT INTO users (email, password, role) VALUES ('admin@example.com', ?, 'admin')";
    
    if ($stmt = $conn->prepare($create_admin)) {
        $stmt->bind_param("s", $admin_password);
        if ($stmt->execute()) {
            echo "Admin user created successfully<br>";
            echo "Email: admin@example.com<br>";
            echo "Password: admin123<br>";
        } else {
            echo "Error creating admin user: " . $stmt->error . "<br>";
        }
        $stmt->close();
    }
} else {
    echo "Admin user already exists<br>";
}

$conn->close();
echo "<br>Setup completed. You can now <a href='login.php'>login</a> with:<br>";
echo "Email: admin@example.com<br>";
echo "Password: admin123";
?> 