<?php
// Include database configuration
require_once 'config.php';
// Note: config.php already handles session start, so we don't need to start it again here

// Handle search
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';

// Pagination setup
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 12;
$offset = ($page - 1) * $records_per_page;

// Build the SQL query based on search
$where_clause = '';
$params = [];
$param_types = '';

if (!empty($search)) {
    $where_clause = "WHERE title LIKE ?";
    $params[] = "%$search%";
    $param_types = 's';
}

// Get total records for pagination
$total_pages_sql = "SELECT COUNT(*) FROM movies " . $where_clause;
if (!empty($params)) {
    $stmt = $conn->prepare($total_pages_sql);
    $stmt->bind_param($param_types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $total_rows = $result->fetch_array()[0];
    $stmt->close();
} else {
    $result = $conn->query($total_pages_sql);
    $total_rows = $result->fetch_array()[0];
}

$total_pages = ceil($total_rows / $records_per_page);

// Get movies with pagination and search
$sql = "SELECT m.*, u.name as added_by_name 
        FROM movies m
        LEFT JOIN users u ON m.added_by = u.id " .
        $where_clause . 
        " ORDER BY m.created_at DESC LIMIT ?, ?";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $params[] = $offset;
    $params[] = $records_per_page;
    $param_types .= 'ii';
    $stmt->bind_param($param_types, ...$params);
} else {
    $stmt->bind_param('ii', $offset, $records_per_page);
}

$stmt->execute();
$movies = $stmt->get_result();
$stmt->close();

// Check if user is logged in and is admin


// Function to convert old movie format to new format
function convertMovieFormat() {
    global $conn;
    
    // Check if conversion has already been done
    $check_sql = "SHOW COLUMNS FROM movies LIKE 'converted'";
    $check_result = $conn->query($check_sql);
    
    if ($check_result->num_rows == 0) {
        // Add 'converted' column to track conversion status
        $alter_sql = "ALTER TABLE movies ADD COLUMN converted TINYINT(1) DEFAULT 0";
        if (!$conn->query($alter_sql)) {
            return [
                'status' => 'error',
                'message' => 'Failed to add conversion tracking column: ' . $conn->error
            ];
        }
    }
    
    // Get all unconverted movies
    $sql = "SELECT * FROM movies WHERE converted = 0 OR converted IS NULL";
    $result = $conn->query($sql);
    
    if (!$result) {
        return [
            'status' => 'error',
            'message' => 'Failed to fetch movies: ' . $conn->error
        ];
    }
    
    $converted_count = 0;
    $error_count = 0;
    
    // Process each movie
    while ($movie = $result->fetch_assoc()) {
        // Convert poster URL if needed (example: updating domain or path structure)
        $new_poster_url = updatePosterUrl($movie['poster_url']);
        
        // Convert watch link if needed (example: updating link structure or adding tracking parameters)
        $new_watch_link = updateWatchLink($movie['watch_link']);
        
        // Update the movie with new format
        $update_sql = "UPDATE movies SET 
                      poster_url = ?, 
                      watch_link = ?, 
                      converted = 1 
                      WHERE id = ?";
        
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("ssi", $new_poster_url, $new_watch_link, $movie['id']);
        
        if ($stmt->execute()) {
            $converted_count++;
        } else {
            $error_count++;
        }
        
        $stmt->close();
    }
    
    return [
        'status' => 'success',
        'converted' => $converted_count,
        'errors' => $error_count,
        'message' => "Conversion completed: $converted_count movies converted, $error_count errors."
    ];
}

// Function to update poster URL format
function updatePosterUrl($url) {
    // Example conversion: Change from old domain to new domain
    // or convert from relative to absolute paths
    if (empty($url)) {
        return 'https://via.placeholder.com/300x450?text=No+Poster';
    }
    
    // Example: Convert old domain to new domain
    $url = str_replace('old-domain.com/images', 'new-domain.com/posters', $url);
    
    // Ensure URL starts with http:// or https://
    if (!preg_match('~^(?:f|ht)tps?://~i', $url)) {
        $url = 'https://' . $url;
    }
    
    return $url;
}

// Function to update watch link format
function updateWatchLink($link) {
    // Example conversion: Update link structure or add tracking parameters
    if (empty($link)) {
        return '';
    }
    
    // Example: Add tracking parameter
    if (strpos($link, '?') !== false) {
        $link .= '&source=movielinks';
    } else {
        $link .= '?source=movielinks';
    }
    
    // Ensure link starts with http:// or https://
    if (!preg_match('~^(?:f|ht)tps?://~i', $link)) {
        $link = 'https://' . $link;
    }
    
    return $link;
}

// Handle form submission
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['convert'])) {
    $result = convertMovieFormat();
    
    // Set flash message
    setFlashMessage($result['status'] === 'success' ? 'success' : 'danger', $result['message']);
    
    // Redirect to avoid form resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MovieLinks - Share and Watch Movies</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main {
            flex: 1 0 auto;
        }
        footer {
            flex-shrink: 0;
        }
        .movie-card {
            transition: transform 0.2s;
            height: 100%;
        }
        .movie-card:hover {
            transform: translateY(-5px);
        }
        .movie-poster {
            height: 300px;
            object-fit: cover;
            width: 100%;
        }
        @media (max-width: 768px) {
            .movie-poster {
                height: 250px;
            }
        }
        #searchSpinner {
            display: none;
        }
        .search-wrapper {
            position: relative;
            max-width: 600px;
            margin: 0 auto;
        }
        .search-wrapper .spinner-border {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 1.2rem;
            height: 1.2rem;
        }
        .card-body {
            display: flex;
            flex-direction: column;
        }
        .card-text {
            flex-grow: 1;
        }
        .pagination {
            flex-wrap: wrap;
            justify-content: center;
            gap: 5px;
        }
        @media (max-width: 576px) {
            .container {
                padding-left: 10px;
                padding-right: 10px;
            }
            .card-title {
                font-size: 1.1rem;
            }
            .card-text {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-film"></i> BihariBabu
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">
                            <i class="bi bi-house"></i> Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if (isLoggedIn() && isAdmin()): ?>
                            <a class="nav-link" href="admin/index.php">
                                <i class="bi bi-speedometer2"></i> Admin Panel
                            </a>
                        <?php else: ?>
                            <a class="nav-link" href="login.php">
                                <i class="bi bi-speedometer2"></i> Admin Panel
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-shrink-0">
        <div class="container my-5">
            <?php displayFlashMessage(); ?>
            
            <!-- Search Form -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="search-wrapper">
                        <input type="text" 
                               id="movieSearch" 
                               class="form-control" 
                               placeholder="Search movies..." 
                               value="<?php echo htmlspecialchars($search); ?>"
                               autocomplete="off">
                        <div id="searchSpinner" class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Movies Grid -->
            <div id="moviesGrid" class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
                <?php if ($movies->num_rows > 0): ?>
                    <?php while($movie = $movies->fetch_assoc()): ?>
                        <div class="col">
                            <div class="card h-100 shadow movie-card">
                                <img src="<?php echo htmlspecialchars($movie['poster_url'] ?: 'https://via.placeholder.com/300x450?text=No+Poster'); ?>" 
                                     class="card-img-top movie-poster" 
                                     alt="<?php echo htmlspecialchars($movie['title']); ?>"
                                     loading="lazy">
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title"><?php echo htmlspecialchars($movie['title']); ?></h5>
                                    <p class="card-text text-muted small">
                                        <!-- Added by: <?php echo htmlspecialchars($movie['added_by_name'] ?? 'Unknown'); ?> -->
                                    </p>
                                    <p class="card-text flex-grow-1">
                                        <?php 
                                        $desc = $movie['description'];
                                        echo htmlspecialchars(strlen($desc) > 100 ? substr($desc, 0, 100) . '...' : $desc); 
                                        ?>
                                    </p>
                                    <div class="mt-auto">
                                        <a href="<?php echo htmlspecialchars($movie['watch_link']); ?>" 
                                           class="btn btn-primary w-100" 
                                           target="_blank">
                                            <i class="bi bi-play-circle"></i> Watch Now
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="col-12 text-center">
                        <div class="alert alert-info">
                            <?php if (!empty($search)): ?>
                                No movies found matching "<?php echo htmlspecialchars($search); ?>".
                            <?php else: ?>
                                No movies available yet.
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <div id="paginationContainer" class="mt-4">
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Movie pagination">
                        <ul class="pagination justify-content-center flex-wrap">
                            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="javascript:void(0)" data-page="<?php echo $page-1; ?>">Previous</a>
                            </li>
                            <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                                    <a class="page-link" href="javascript:void(0)" data-page="<?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="javascript:void(0)" data-page="<?php echo $page+1; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer mt-auto py-3 bg-dark text-white">
        <div class="container">
            <div class="row gy-3">
                <div class="col-md-6">
                    <h5><i class="bi bi-film"></i> BihariBabu</h5>
                    <p class="mb-0">Share and watch your favorite movies with friends.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0">&copy; <?php echo date("Y"); ?> BihariBabu. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let searchTimeout = null;
        const searchInput = document.getElementById('movieSearch');
        const moviesGrid = document.getElementById('moviesGrid');
        const paginationContainer = document.getElementById('paginationContainer');
        const searchSpinner = document.getElementById('searchSpinner');
        let currentPage = 1;

        // Function to update movies grid
        async function updateMovies(search, page = 1) {
            searchSpinner.style.display = 'block';
            
            try {
                const response = await fetch(`get_movies.php?search=${encodeURIComponent(search)}&page=${page}`);
                const data = await response.json();
                
                if (data.success) {
                    moviesGrid.innerHTML = data.html;
                    paginationContainer.innerHTML = data.pagination;
                    
                    // Reinitialize pagination event listeners
                    initializePagination();
                }
            } catch (error) {
                console.error('Error fetching movies:', error);
            } finally {
                searchSpinner.style.display = 'none';
            }
        }

        // Function to initialize pagination event listeners
        function initializePagination() {
            document.querySelectorAll('.page-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const page = this.dataset.page;
                    if (page) {
                        currentPage = parseInt(page);
                        updateMovies(searchInput.value, currentPage);
                    }
                });
            });
        }

        // Search input event listener
        searchInput.addEventListener('input', function(e) {
            clearTimeout(searchTimeout);
            
            searchTimeout = setTimeout(() => {
                currentPage = 1; // Reset to first page on new search
                updateMovies(e.target.value);
            }, 300); // Wait 300ms after user stops typing
        });

        // Initialize pagination on page load
        initializePagination();
    </script>
</body>
</html>